package com.mn.entity;

public class Missing {
}
