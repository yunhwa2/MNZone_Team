package com.mn.entity;

public class Hospital {
}
