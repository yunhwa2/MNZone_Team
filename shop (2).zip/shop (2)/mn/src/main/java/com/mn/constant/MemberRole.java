package com.mn.constant;

public enum MemberRole {
    USER, ADMIN
}
