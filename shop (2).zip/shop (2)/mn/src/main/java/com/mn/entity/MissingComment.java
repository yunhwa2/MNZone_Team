package com.mn.entity;

public class MissingComment {
}
