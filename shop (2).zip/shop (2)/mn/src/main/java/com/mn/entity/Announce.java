package com.mn.entity;

import com.mn.constant.MemberRole;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;


public class Announce {



}
