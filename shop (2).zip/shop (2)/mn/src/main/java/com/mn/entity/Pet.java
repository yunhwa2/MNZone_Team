package com.mn.entity;

public class Pet {
}
