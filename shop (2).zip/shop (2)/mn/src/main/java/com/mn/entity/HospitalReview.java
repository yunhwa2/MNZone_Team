package com.mn.entity;

public class HospitalReview {
}
