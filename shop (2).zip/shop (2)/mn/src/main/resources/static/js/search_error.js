/**
 * 
 */

let input_val = window.name;
$("#search_item").text(input_val);


